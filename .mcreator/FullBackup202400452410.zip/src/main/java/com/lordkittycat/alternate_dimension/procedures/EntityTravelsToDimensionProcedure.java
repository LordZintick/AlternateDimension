package com.lordkittycat.alternate_dimension.procedures;

import net.neoforged.neoforge.event.entity.EntityTravelToDimensionEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.protocol.game.ClientboundUpdateMobEffectPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ClientboundLevelEventPacket;
import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

import com.lordkittycat.alternate_dimension.network.AlternateDimensionModVariables;
import com.lordkittycat.alternate_dimension.init.AlternateDimensionModMobEffects;
import com.lordkittycat.alternate_dimension.AlternateDimensionMod;

@EventBusSubscriber
public class EntityTravelsToDimensionProcedure {
	@SubscribeEvent
	public static void onEntityTravelToDimension(EntityTravelToDimensionEvent event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getDimension(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, ResourceKey<Level> dimension, Entity entity) {
		execute(null, world, x, y, z, dimension, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, ResourceKey<Level> dimension, Entity entity) {
		if (dimension == null || entity == null)
			return;
		if (!(dimension == ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse("alternate_dimension:familiar_realm"))) && !(dimension == Level.END) && !(dimension == Level.OVERWORLD)) {
			{
				AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
				_vars.canEnterPortal = false;
				_vars.syncPlayerVariables(entity);
			}
			{
				AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
				_vars.exitX = x;
				_vars.syncPlayerVariables(entity);
			}
			{
				AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
				_vars.exitY = y;
				_vars.syncPlayerVariables(entity);
			}
			{
				AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
				_vars.exitZ = z;
				_vars.syncPlayerVariables(entity);
			}
			AlternateDimensionMod.queueServerWork(80, () -> {
				{
					AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
					_vars.canEnterPortal = true;
					_vars.syncPlayerVariables(entity);
				}
			});
		}
		if (dimension == Level.END) {
			if (world instanceof ServerLevel _origLevel) {
				LevelAccessor _worldorig = world;
				world = _origLevel.getServer().getLevel(Level.OVERWORLD);
				if (world != null) {
					if (entity instanceof ServerPlayer _serverPlayer)
						_serverPlayer.setRespawnPosition(_serverPlayer.level().dimension(), new BlockPos(0, 128, 0), _serverPlayer.getYRot(), true, false);
				}
				world = _worldorig;
			}
		}
		if (dimension == Level.OVERWORLD) {
			if (world instanceof ServerLevel _origLevel) {
				LevelAccessor _worldorig = world;
				world = _origLevel.getServer().getLevel(ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse("alternate_dimension:familiar_realm")));
				if (world != null) {
					while (!((world.getBlockState(BlockPos.containing(entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitX, entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitY,
							entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitZ))).getBlock() == Blocks.AIR)
							&& !((world.getBlockState(BlockPos.containing(entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitX, entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitY,
									entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitZ))).getBlock() == Blocks.CAVE_AIR)) {
						{
							AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
							_vars.exitX = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitX + Mth.nextInt(RandomSource.create(), 1, 10);
							_vars.syncPlayerVariables(entity);
						}
						{
							AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
							_vars.exitY = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitY + Mth.nextInt(RandomSource.create(), 1, 10);
							_vars.syncPlayerVariables(entity);
						}
						{
							AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
							_vars.exitZ = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitZ + Mth.nextInt(RandomSource.create(), 1, 10);
							_vars.syncPlayerVariables(entity);
						}
					}
				}
				world = _worldorig;
			}
			{
				AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
				_vars.canEnterPortal = false;
				_vars.syncPlayerVariables(entity);
			}
			AlternateDimensionMod.queueServerWork(1, () -> {
				if (entity instanceof ServerPlayer _player && !_player.level().isClientSide()) {
					ResourceKey<Level> destinationType = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse("alternate_dimension:familiar_realm"));
					if (_player.level().dimension() == destinationType)
						return;
					ServerLevel nextLevel = _player.server.getLevel(destinationType);
					if (nextLevel != null) {
						_player.connection.send(new ClientboundGameEventPacket(ClientboundGameEventPacket.WIN_GAME, 0));
						_player.teleportTo(nextLevel, _player.getX(), _player.getY(), _player.getZ(), _player.getYRot(), _player.getXRot());
						_player.connection.send(new ClientboundPlayerAbilitiesPacket(_player.getAbilities()));
						for (MobEffectInstance _effectinstance : _player.getActiveEffects())
							_player.connection.send(new ClientboundUpdateMobEffectPacket(_player.getId(), _effectinstance, false));
						_player.connection.send(new ClientboundLevelEventPacket(1032, BlockPos.ZERO, 0, false));
					}
				}
				AlternateDimensionMod.queueServerWork(1, () -> {
					{
						Entity _ent = entity;
						_ent.teleportTo(entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitX, entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitY,
								entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitZ);
						if (_ent instanceof ServerPlayer _serverPlayer)
							_serverPlayer.connection.teleport(entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitX, entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitY,
									entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).exitZ, _ent.getYRot(), _ent.getXRot());
					}
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(AlternateDimensionModMobEffects.LIGHT_FOOTED_EFFECT, 100, 0));
					AlternateDimensionMod.queueServerWork(80, () -> {
						{
							AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
							_vars.canEnterPortal = true;
							_vars.syncPlayerVariables(entity);
						}
					});
				});
			});
		}
	}
}
