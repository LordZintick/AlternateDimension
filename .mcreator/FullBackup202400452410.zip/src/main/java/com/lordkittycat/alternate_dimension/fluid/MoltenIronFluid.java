
package com.lordkittycat.alternate_dimension.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import com.lordkittycat.alternate_dimension.init.AlternateDimensionModItems;
import com.lordkittycat.alternate_dimension.init.AlternateDimensionModFluids;
import com.lordkittycat.alternate_dimension.init.AlternateDimensionModFluidTypes;
import com.lordkittycat.alternate_dimension.init.AlternateDimensionModBlocks;

public abstract class MoltenIronFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> AlternateDimensionModFluidTypes.MOLTEN_IRON_TYPE.get(), () -> AlternateDimensionModFluids.MOLTEN_IRON.get(),
			() -> AlternateDimensionModFluids.FLOWING_MOLTEN_IRON.get()).explosionResistance(100f).tickRate(30).bucket(() -> AlternateDimensionModItems.MOLTEN_IRON_BUCKET.get())
			.block(() -> (LiquidBlock) AlternateDimensionModBlocks.MOLTEN_IRON.get());

	private MoltenIronFluid() {
		super(PROPERTIES);
	}

	public static class Source extends MoltenIronFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends MoltenIronFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
