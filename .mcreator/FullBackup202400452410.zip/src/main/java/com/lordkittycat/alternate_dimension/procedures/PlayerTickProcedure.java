package com.lordkittycat.alternate_dimension.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;

import javax.annotation.Nullable;

import com.lordkittycat.alternate_dimension.network.AlternateDimensionModVariables;
import com.lordkittycat.alternate_dimension.init.AlternateDimensionModItems;

@EventBusSubscriber
public class PlayerTickProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).jetpackHover && entity.getDeltaMovement().y() < 0
				&& ((entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(AlternateDimensionModItems.CANDY_CANE.get())) : false)
						|| entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).burnTime > 0)
				&& entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).jetpackEngine
				&& (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY).getItem() == AlternateDimensionModItems.CANDY_ARMOR_CHESTPLATE.get()) {
			if (entity instanceof LivingEntity _livingEntity4 && _livingEntity4.getAttributes().hasAttribute(Attributes.FLYING_SPEED))
				_livingEntity4.getAttribute(Attributes.FLYING_SPEED).setBaseValue(0.7);
			entity.fallDistance = 0;
			entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x()), 0, (entity.getDeltaMovement().z())));
			if ((entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(AlternateDimensionModItems.CANDY_CANE.get())) : false) && entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).burnTime <= 0) {
				if (entity instanceof Player _player) {
					ItemStack _stktoremove = new ItemStack(AlternateDimensionModItems.CANDY_CANE.get());
					_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
				}
				{
					AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
					_vars.burnTime = 20;
					_vars.syncPlayerVariables(entity);
				}
			} else {
				{
					AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
					_vars.burnTime = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).burnTime - 1;
					_vars.syncPlayerVariables(entity);
				}
			}
		} else {
			if (entity instanceof LivingEntity _livingEntity11 && _livingEntity11.getAttributes().hasAttribute(Attributes.FLYING_SPEED))
				_livingEntity11.getAttribute(Attributes.FLYING_SPEED).setBaseValue(0.1);
		}
	}
}
