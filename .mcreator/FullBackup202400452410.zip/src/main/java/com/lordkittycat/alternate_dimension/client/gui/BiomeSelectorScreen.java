package com.lordkittycat.alternate_dimension.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

import com.lordkittycat.alternate_dimension.world.inventory.BiomeSelectorMenu;
import com.lordkittycat.alternate_dimension.network.BiomeSelectorButtonMessage;

public class BiomeSelectorScreen extends AbstractContainerScreen<BiomeSelectorMenu> {
	private final static HashMap<String, Object> guistate = BiomeSelectorMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	EditBox biome_input;
	Button button_confirm;

	public BiomeSelectorScreen(BiomeSelectorMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 138;
		this.imageHeight = 70;
	}

	private static final ResourceLocation texture = ResourceLocation.parse("alternate_dimension:textures/screens/biome_selector.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics, mouseX, mouseY, partialTicks);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		biome_input.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		if (biome_input.isFocused())
			return biome_input.keyPressed(key, b, c);
		return super.keyPressed(key, b, c);
	}

	@Override
	public void resize(Minecraft minecraft, int width, int height) {
		String biome_inputValue = biome_input.getValue();
		super.resize(minecraft, width, height);
		biome_input.setValue(biome_inputValue);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.alternate_dimension.biome_selector.label_biome_locator"), 33, 5, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		biome_input = new EditBox(this.font, this.leftPos + 12, this.topPos + 19, 118, 18, Component.translatable("gui.alternate_dimension.biome_selector.biome_input")) {
			@Override
			public void insertText(String text) {
				super.insertText(text);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.alternate_dimension.biome_selector.biome_input").getString());
				else
					setSuggestion(null);
			}

			@Override
			public void moveCursorTo(int pos, boolean flag) {
				super.moveCursorTo(pos, flag);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.alternate_dimension.biome_selector.biome_input").getString());
				else
					setSuggestion(null);
			}
		};
		biome_input.setMaxLength(32767);
		biome_input.setSuggestion(Component.translatable("gui.alternate_dimension.biome_selector.biome_input").getString());
		guistate.put("text:biome_input", biome_input);
		this.addWidget(this.biome_input);
		button_confirm = Button.builder(Component.translatable("gui.alternate_dimension.biome_selector.button_confirm"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new BiomeSelectorButtonMessage(0, x, y, z));
				BiomeSelectorButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 36, this.topPos + 43, 61, 20).build();
		guistate.put("button:button_confirm", button_confirm);
		this.addRenderableWidget(button_confirm);
	}
}
