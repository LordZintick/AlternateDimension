
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.lordkittycat.alternate_dimension.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import com.lordkittycat.alternate_dimension.block.WildBushBlock;
import com.lordkittycat.alternate_dimension.block.WhippedCreamBlockBlock;
import com.lordkittycat.alternate_dimension.block.WaffleBlockBlock;
import com.lordkittycat.alternate_dimension.block.UraniumOreBlock;
import com.lordkittycat.alternate_dimension.block.UraniumBlockBlock;
import com.lordkittycat.alternate_dimension.block.TitaniumOreBlock;
import com.lordkittycat.alternate_dimension.block.TitaniumBlockBlock;
import com.lordkittycat.alternate_dimension.block.TinOreBlock;
import com.lordkittycat.alternate_dimension.block.TinBlockBlock;
import com.lordkittycat.alternate_dimension.block.SulfurOreBlock;
import com.lordkittycat.alternate_dimension.block.SugariumOreBlock;
import com.lordkittycat.alternate_dimension.block.SugariumBlockBlock;
import com.lordkittycat.alternate_dimension.block.SugarBlockBlock;
import com.lordkittycat.alternate_dimension.block.StrawberryBushBlock;
import com.lordkittycat.alternate_dimension.block.StoneTilesBlock;
import com.lordkittycat.alternate_dimension.block.SolarPanelBlock;
import com.lordkittycat.alternate_dimension.block.SkyStoneBlock;
import com.lordkittycat.alternate_dimension.block.ServerStationBlock;
import com.lordkittycat.alternate_dimension.block.ScorchedEarthBlock;
import com.lordkittycat.alternate_dimension.block.ScorchedBushBlock;
import com.lordkittycat.alternate_dimension.block.ScorchedBricksBlock;
import com.lordkittycat.alternate_dimension.block.ScorchedBrickStairsBlock;
import com.lordkittycat.alternate_dimension.block.ScorchedBrickSlabBlock;
import com.lordkittycat.alternate_dimension.block.SaltBlockBlock;
import com.lordkittycat.alternate_dimension.block.RestlessBeetleNestBlock;
import com.lordkittycat.alternate_dimension.block.RefinedMeteoriteBlockBlock;
import com.lordkittycat.alternate_dimension.block.RaspberryBushBlock;
import com.lordkittycat.alternate_dimension.block.QuartzOreBlock;
import com.lordkittycat.alternate_dimension.block.PortalBlockBlock;
import com.lordkittycat.alternate_dimension.block.PineLeavesBlock;
import com.lordkittycat.alternate_dimension.block.ParmesanCheeseBlockBlock;
import com.lordkittycat.alternate_dimension.block.OrichalcumOreBlock;
import com.lordkittycat.alternate_dimension.block.OrichalcumBlockBlock;
import com.lordkittycat.alternate_dimension.block.NuclearReactorBlock;
import com.lordkittycat.alternate_dimension.block.MoltenIronBlock;
import com.lordkittycat.alternate_dimension.block.MoltenGoldBlock;
import com.lordkittycat.alternate_dimension.block.MoltenDiamondBlock;
import com.lordkittycat.alternate_dimension.block.MeteoriteBlockBlock;
import com.lordkittycat.alternate_dimension.block.MagicDustBlockBlock;
import com.lordkittycat.alternate_dimension.block.LightningBlockBlock;
import com.lordkittycat.alternate_dimension.block.IngotPresserBlock;
import com.lordkittycat.alternate_dimension.block.ImbunementTableBlock;
import com.lordkittycat.alternate_dimension.block.IceCreamBlockBlock;
import com.lordkittycat.alternate_dimension.block.HomeBlockBlock;
import com.lordkittycat.alternate_dimension.block.HempPlantBlock;
import com.lordkittycat.alternate_dimension.block.HeartOfNatureBlock;
import com.lordkittycat.alternate_dimension.block.GeneratorBlock;
import com.lordkittycat.alternate_dimension.block.GelatinBlockBlock;
import com.lordkittycat.alternate_dimension.block.FrostingBlock;
import com.lordkittycat.alternate_dimension.block.EvilstoneOreBlock;
import com.lordkittycat.alternate_dimension.block.EvilstoneBlockBlock;
import com.lordkittycat.alternate_dimension.block.ElectricSmelterBlock;
import com.lordkittycat.alternate_dimension.block.DriedFruitBlock;
import com.lordkittycat.alternate_dimension.block.DeepslateUraniumOreBlock;
import com.lordkittycat.alternate_dimension.block.DeepslateTitaniumOreBlock;
import com.lordkittycat.alternate_dimension.block.CorruptorBlock;
import com.lordkittycat.alternate_dimension.block.CoolantRodsBlock;
import com.lordkittycat.alternate_dimension.block.CookingCoreBlock;
import com.lordkittycat.alternate_dimension.block.CookieBlockBlock;
import com.lordkittycat.alternate_dimension.block.CompressedBarkBlock;
import com.lordkittycat.alternate_dimension.block.CloudPillarBlock;
import com.lordkittycat.alternate_dimension.block.CloudBricksBlock;
import com.lordkittycat.alternate_dimension.block.CloudBrickStairsBlock;
import com.lordkittycat.alternate_dimension.block.CloudBrickSlabBlock;
import com.lordkittycat.alternate_dimension.block.CloudBlockBlock;
import com.lordkittycat.alternate_dimension.block.CircuitMakerBlock;
import com.lordkittycat.alternate_dimension.block.CheeseBlockBlock;
import com.lordkittycat.alternate_dimension.block.CandyCaneBlockBlock;
import com.lordkittycat.alternate_dimension.block.BushLeavesBlock;
import com.lordkittycat.alternate_dimension.block.BlueberryBushBlock;
import com.lordkittycat.alternate_dimension.block.BeetleNestBlock;
import com.lordkittycat.alternate_dimension.block.BasicEnergyCableBlock;
import com.lordkittycat.alternate_dimension.block.AppleLeavesBlock;
import com.lordkittycat.alternate_dimension.block.AlloySmelterBlock;
import com.lordkittycat.alternate_dimension.block.AeroCoreBlock;
import com.lordkittycat.alternate_dimension.AlternateDimensionMod;

public class AlternateDimensionModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(AlternateDimensionMod.MODID);
	public static final DeferredBlock<Block> TITANIUM_ORE = REGISTRY.register("titanium_ore", TitaniumOreBlock::new);
	public static final DeferredBlock<Block> TITANIUM_BLOCK = REGISTRY.register("titanium_block", TitaniumBlockBlock::new);
	public static final DeferredBlock<Block> DEEPSLATE_TITANIUM_ORE = REGISTRY.register("deepslate_titanium_ore", DeepslateTitaniumOreBlock::new);
	public static final DeferredBlock<Block> SCORCHED_EARTH = REGISTRY.register("scorched_earth", ScorchedEarthBlock::new);
	public static final DeferredBlock<Block> DRIED_FRUIT = REGISTRY.register("dried_fruit", DriedFruitBlock::new);
	public static final DeferredBlock<Block> CIRCUIT_MAKER = REGISTRY.register("circuit_maker", CircuitMakerBlock::new);
	public static final DeferredBlock<Block> INGOT_PRESSER = REGISTRY.register("ingot_presser", IngotPresserBlock::new);
	public static final DeferredBlock<Block> QUARTZ_ORE = REGISTRY.register("quartz_ore", QuartzOreBlock::new);
	public static final DeferredBlock<Block> GENERATOR = REGISTRY.register("generator", GeneratorBlock::new);
	public static final DeferredBlock<Block> MOLTEN_IRON = REGISTRY.register("molten_iron", MoltenIronBlock::new);
	public static final DeferredBlock<Block> MOLTEN_GOLD = REGISTRY.register("molten_gold", MoltenGoldBlock::new);
	public static final DeferredBlock<Block> SOLAR_PANEL = REGISTRY.register("solar_panel", SolarPanelBlock::new);
	public static final DeferredBlock<Block> MOLTEN_DIAMOND = REGISTRY.register("molten_diamond", MoltenDiamondBlock::new);
	public static final DeferredBlock<Block> BASIC_ENERGY_CABLE = REGISTRY.register("basic_energy_cable", BasicEnergyCableBlock::new);
	public static final DeferredBlock<Block> COMPRESSED_BARK = REGISTRY.register("compressed_bark", CompressedBarkBlock::new);
	public static final DeferredBlock<Block> TIN_ORE = REGISTRY.register("tin_ore", TinOreBlock::new);
	public static final DeferredBlock<Block> TIN_BLOCK = REGISTRY.register("tin_block", TinBlockBlock::new);
	public static final DeferredBlock<Block> BEETLE_NEST = REGISTRY.register("beetle_nest", BeetleNestBlock::new);
	public static final DeferredBlock<Block> WILD_BUSH = REGISTRY.register("wild_bush", WildBushBlock::new);
	public static final DeferredBlock<Block> SCORCHED_BUSH = REGISTRY.register("scorched_bush", ScorchedBushBlock::new);
	public static final DeferredBlock<Block> SALT_BLOCK = REGISTRY.register("salt_block", SaltBlockBlock::new);
	public static final DeferredBlock<Block> FROSTING = REGISTRY.register("frosting", FrostingBlock::new);
	public static final DeferredBlock<Block> CANDY_CANE_BLOCK = REGISTRY.register("candy_cane_block", CandyCaneBlockBlock::new);
	public static final DeferredBlock<Block> WAFFLE_BLOCK = REGISTRY.register("waffle_block", WaffleBlockBlock::new);
	public static final DeferredBlock<Block> COOKIE_BLOCK = REGISTRY.register("cookie_block", CookieBlockBlock::new);
	public static final DeferredBlock<Block> CHEESE_BLOCK = REGISTRY.register("cheese_block", CheeseBlockBlock::new);
	public static final DeferredBlock<Block> LIGHTNING_BLOCK = REGISTRY.register("lightning_block", LightningBlockBlock::new);
	public static final DeferredBlock<Block> BUSH_LEAVES = REGISTRY.register("bush_leaves", BushLeavesBlock::new);
	public static final DeferredBlock<Block> STONE_TILES = REGISTRY.register("stone_tiles", StoneTilesBlock::new);
	public static final DeferredBlock<Block> PARMESAN_CHEESE_BLOCK = REGISTRY.register("parmesan_cheese_block", ParmesanCheeseBlockBlock::new);
	public static final DeferredBlock<Block> HEMP_PLANT = REGISTRY.register("hemp_plant", HempPlantBlock::new);
	public static final DeferredBlock<Block> SUGAR_BLOCK = REGISTRY.register("sugar_block", SugarBlockBlock::new);
	public static final DeferredBlock<Block> SUGARIUM_ORE = REGISTRY.register("sugarium_ore", SugariumOreBlock::new);
	public static final DeferredBlock<Block> SUGARIUM_BLOCK = REGISTRY.register("sugarium_block", SugariumBlockBlock::new);
	public static final DeferredBlock<Block> SERVER_STATION = REGISTRY.register("server_station", ServerStationBlock::new);
	public static final DeferredBlock<Block> COOKING_CORE = REGISTRY.register("cooking_core", CookingCoreBlock::new);
	public static final DeferredBlock<Block> SKY_STONE = REGISTRY.register("sky_stone", SkyStoneBlock::new);
	public static final DeferredBlock<Block> METEORITE_BLOCK = REGISTRY.register("meteorite_block", MeteoriteBlockBlock::new);
	public static final DeferredBlock<Block> SCORCHED_BRICKS = REGISTRY.register("scorched_bricks", ScorchedBricksBlock::new);
	public static final DeferredBlock<Block> SCORCHED_BRICK_SLAB = REGISTRY.register("scorched_brick_slab", ScorchedBrickSlabBlock::new);
	public static final DeferredBlock<Block> SCORCHED_BRICK_STAIRS = REGISTRY.register("scorched_brick_stairs", ScorchedBrickStairsBlock::new);
	public static final DeferredBlock<Block> RESTLESS_BEETLE_NEST = REGISTRY.register("restless_beetle_nest", RestlessBeetleNestBlock::new);
	public static final DeferredBlock<Block> CLOUD_BLOCK = REGISTRY.register("cloud_block", CloudBlockBlock::new);
	public static final DeferredBlock<Block> SULFUR_ORE = REGISTRY.register("sulfur_ore", SulfurOreBlock::new);
	public static final DeferredBlock<Block> IMBUNEMENT_TABLE = REGISTRY.register("imbunement_table", ImbunementTableBlock::new);
	public static final DeferredBlock<Block> HEART_OF_NATURE = REGISTRY.register("heart_of_nature", HeartOfNatureBlock::new);
	public static final DeferredBlock<Block> CORRUPTOR = REGISTRY.register("corruptor", CorruptorBlock::new);
	public static final DeferredBlock<Block> EVILSTONE_ORE = REGISTRY.register("evilstone_ore", EvilstoneOreBlock::new);
	public static final DeferredBlock<Block> ELECTRIC_SMELTER = REGISTRY.register("electric_smelter", ElectricSmelterBlock::new);
	public static final DeferredBlock<Block> ORICHALCUM_ORE = REGISTRY.register("orichalcum_ore", OrichalcumOreBlock::new);
	public static final DeferredBlock<Block> CLOUD_BRICKS = REGISTRY.register("cloud_bricks", CloudBricksBlock::new);
	public static final DeferredBlock<Block> CLOUD_BRICK_SLAB = REGISTRY.register("cloud_brick_slab", CloudBrickSlabBlock::new);
	public static final DeferredBlock<Block> CLOUD_BRICK_STAIRS = REGISTRY.register("cloud_brick_stairs", CloudBrickStairsBlock::new);
	public static final DeferredBlock<Block> URANIUM_ORE = REGISTRY.register("uranium_ore", UraniumOreBlock::new);
	public static final DeferredBlock<Block> DEEPSLATE_URANIUM_ORE = REGISTRY.register("deepslate_uranium_ore", DeepslateUraniumOreBlock::new);
	public static final DeferredBlock<Block> COOLANT_RODS = REGISTRY.register("coolant_rods", CoolantRodsBlock::new);
	public static final DeferredBlock<Block> NUCLEAR_REACTOR = REGISTRY.register("nuclear_reactor", NuclearReactorBlock::new);
	public static final DeferredBlock<Block> CLOUD_PILLAR = REGISTRY.register("cloud_pillar", CloudPillarBlock::new);
	public static final DeferredBlock<Block> AERO_CORE = REGISTRY.register("aero_core", AeroCoreBlock::new);
	public static final DeferredBlock<Block> PINE_LEAVES = REGISTRY.register("pine_leaves", PineLeavesBlock::new);
	public static final DeferredBlock<Block> HOME_BLOCK = REGISTRY.register("home_block", HomeBlockBlock::new);
	public static final DeferredBlock<Block> ALLOY_SMELTER = REGISTRY.register("alloy_smelter", AlloySmelterBlock::new);
	public static final DeferredBlock<Block> REFINED_METEORITE_BLOCK = REGISTRY.register("refined_meteorite_block", RefinedMeteoriteBlockBlock::new);
	public static final DeferredBlock<Block> EVILSTONE_BLOCK = REGISTRY.register("evilstone_block", EvilstoneBlockBlock::new);
	public static final DeferredBlock<Block> MAGIC_DUST_BLOCK = REGISTRY.register("magic_dust_block", MagicDustBlockBlock::new);
	public static final DeferredBlock<Block> ORICHALCUM_BLOCK = REGISTRY.register("orichalcum_block", OrichalcumBlockBlock::new);
	public static final DeferredBlock<Block> URANIUM_BLOCK = REGISTRY.register("uranium_block", UraniumBlockBlock::new);
	public static final DeferredBlock<Block> ICE_CREAM_BLOCK = REGISTRY.register("ice_cream_block", IceCreamBlockBlock::new);
	public static final DeferredBlock<Block> GELATIN_BLOCK = REGISTRY.register("gelatin_block", GelatinBlockBlock::new);
	public static final DeferredBlock<Block> WHIPPED_CREAM_BLOCK = REGISTRY.register("whipped_cream_block", WhippedCreamBlockBlock::new);
	public static final DeferredBlock<Block> APPLE_LEAVES = REGISTRY.register("apple_leaves", AppleLeavesBlock::new);
	public static final DeferredBlock<Block> STRAWBERRY_BUSH = REGISTRY.register("strawberry_bush", StrawberryBushBlock::new);
	public static final DeferredBlock<Block> RASPBERRY_BUSH = REGISTRY.register("raspberry_bush", RaspberryBushBlock::new);
	public static final DeferredBlock<Block> BLUEBERRY_BUSH = REGISTRY.register("blueberry_bush", BlueberryBushBlock::new);
	public static final DeferredBlock<Block> PORTAL_BLOCK = REGISTRY.register("portal_block", PortalBlockBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			WildBushBlock.blockColorLoad(event);
			BushLeavesBlock.blockColorLoad(event);
			PineLeavesBlock.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
			WildBushBlock.itemColorLoad(event);
			BushLeavesBlock.itemColorLoad(event);
			PineLeavesBlock.itemColorLoad(event);
		}
	}
}
