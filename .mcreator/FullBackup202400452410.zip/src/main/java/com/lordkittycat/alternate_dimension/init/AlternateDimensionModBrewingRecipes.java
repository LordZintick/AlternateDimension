
package com.lordkittycat.alternate_dimension.init;

import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.component.DataComponents;

import mezz.jei.api.registration.IRecipeRegistration;
import mezz.jei.api.recipe.vanilla.IVanillaRecipeFactory;
import mezz.jei.api.recipe.vanilla.IJeiBrewingRecipe;
import mezz.jei.api.constants.RecipeTypes;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.IModPlugin;

import java.util.List;
import java.util.ArrayList;

@JeiPlugin
public class AlternateDimensionModBrewingRecipes implements IModPlugin {
	@Override
	public ResourceLocation getPluginUid() {
		return ResourceLocation.parse("alternate_dimension:brewing_recipes");
	}

	@Override
	public void registerRecipes(IRecipeRegistration registration) {
		IVanillaRecipeFactory factory = registration.getVanillaRecipeFactory();
		List<IJeiBrewingRecipe> brewingRecipes = new ArrayList<>();
		ItemStack potion = new ItemStack(Items.POTION);
		ItemStack potion2 = new ItemStack(Items.POTION);
		List<ItemStack> ingredientStack = new ArrayList<>();
		List<ItemStack> inputStack = new ArrayList<>();
		ingredientStack.add(new ItemStack(Items.QUARTZ));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.AWKWARD));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), new ItemStack(AlternateDimensionModItems.ACROBATIC_POTION.get())));
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(AlternateDimensionModItems.CLOUD_CHARGE.get()));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.AWKWARD));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), new ItemStack(AlternateDimensionModItems.LIGHT_FOOTED_POTION.get())));
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.STICK));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.AWKWARD));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), new ItemStack(AlternateDimensionModItems.REACHING_POTION.get())));
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(AlternateDimensionModItems.MAGNETIC_TALISMAN.get()));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.AWKWARD));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), new ItemStack(AlternateDimensionModItems.MAGNETISM_POTION.get())));
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(AlternateDimensionModItems.LIGHT_ESSENCE.get()));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.AWKWARD));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), new ItemStack(AlternateDimensionModItems.BLESSED_POTION.get())));
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.MILK_BUCKET));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.AWKWARD));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), new ItemStack(AlternateDimensionModItems.IMMUNITY_POTION.get())));
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.GLOWSTONE_DUST));
		inputStack.add(new ItemStack(AlternateDimensionModItems.IMMUNITY_POTION.get()));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), List.copyOf(inputStack), new ItemStack(AlternateDimensionModItems.IMMUNITY_POTION_2.get())));
		inputStack.clear();
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.GLOWSTONE_DUST));
		inputStack.add(new ItemStack(AlternateDimensionModItems.IMMUNITY_POTION_2.get()));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), List.copyOf(inputStack), new ItemStack(AlternateDimensionModItems.IMMUNITY_POTION_3.get())));
		inputStack.clear();
		ingredientStack.clear();
		ingredientStack.add(new ItemStack(Items.SLIME_BALL));
		potion.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.AWKWARD));
		brewingRecipes.add(factory.createBrewingRecipe(List.copyOf(ingredientStack), potion.copy(), new ItemStack(AlternateDimensionModItems.JUMPY_POTION.get())));
		ingredientStack.clear();
		registration.addRecipes(RecipeTypes.BREWING, brewingRecipes);
	}
}
