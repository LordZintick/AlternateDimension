package com.lordkittycat.alternate_dimension.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

import com.lordkittycat.alternate_dimension.world.inventory.IronOrePromptMenu;
import com.lordkittycat.alternate_dimension.network.IronOrePromptButtonMessage;

public class IronOrePromptScreen extends AbstractContainerScreen<IronOrePromptMenu> {
	private final static HashMap<String, Object> guistate = IronOrePromptMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Button button_yes;
	Button button_no;

	public IronOrePromptScreen(IronOrePromptMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	private static final ResourceLocation texture = ResourceLocation.parse("alternate_dimension:textures/screens/iron_ore_prompt.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics, mouseX, mouseY, partialTicks);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.alternate_dimension.iron_ore_prompt.label_a_seal_protects_this_block_prev"), 7, 7, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.alternate_dimension.iron_ore_prompt.label_preventing_you_from_mining_it"), 6, 18, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.alternate_dimension.iron_ore_prompt.label_attempt_to_break_seal"), 21, 51, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.alternate_dimension.iron_ore_prompt.label_this_starts_a_boss_fight"), 23, 125, -6750208, false);
	}

	@Override
	public void init() {
		super.init();
		button_yes = Button.builder(Component.translatable("gui.alternate_dimension.iron_ore_prompt.button_yes"), e -> {
		}).bounds(this.leftPos + 22, this.topPos + 88, 40, 20).build();
		guistate.put("button:button_yes", button_yes);
		this.addRenderableWidget(button_yes);
		button_no = Button.builder(Component.translatable("gui.alternate_dimension.iron_ore_prompt.button_no"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new IronOrePromptButtonMessage(1, x, y, z));
				IronOrePromptButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 109, this.topPos + 88, 35, 20).build();
		guistate.put("button:button_no", button_no);
		this.addRenderableWidget(button_no);
	}
}
