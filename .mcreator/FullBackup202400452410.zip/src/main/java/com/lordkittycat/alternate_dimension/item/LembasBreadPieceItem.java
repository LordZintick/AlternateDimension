
package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LembasBreadPieceItem extends Item {
	public LembasBreadPieceItem() {
		super(new Item.Properties().durability(4).rarity(Rarity.COMMON));
	}
}
