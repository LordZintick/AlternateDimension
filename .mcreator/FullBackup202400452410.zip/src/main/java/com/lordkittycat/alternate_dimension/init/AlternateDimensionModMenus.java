
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package com.lordkittycat.alternate_dimension.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.core.registries.Registries;

import com.lordkittycat.alternate_dimension.world.inventory.NuclearReactorGUIMenu;
import com.lordkittycat.alternate_dimension.world.inventory.IronOrePromptMenu;
import com.lordkittycat.alternate_dimension.world.inventory.IngotPresserGUIMenu;
import com.lordkittycat.alternate_dimension.world.inventory.IncineratorGUIMenu;
import com.lordkittycat.alternate_dimension.world.inventory.ImbunementGUIMenu;
import com.lordkittycat.alternate_dimension.world.inventory.GeneratorGUIMenu;
import com.lordkittycat.alternate_dimension.world.inventory.ElectricSmelterGUIMenu;
import com.lordkittycat.alternate_dimension.world.inventory.CorruptorGUIMenu;
import com.lordkittycat.alternate_dimension.world.inventory.CircuitMakerGUIMenu;
import com.lordkittycat.alternate_dimension.world.inventory.BiomeSelectorMenu;
import com.lordkittycat.alternate_dimension.world.inventory.BackpackGUIMenu;
import com.lordkittycat.alternate_dimension.world.inventory.AlloySmelterGUIMenu;
import com.lordkittycat.alternate_dimension.AlternateDimensionMod;

public class AlternateDimensionModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, AlternateDimensionMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<CircuitMakerGUIMenu>> CIRCUIT_MAKER_GUI = REGISTRY.register("circuit_maker_gui", () -> IMenuTypeExtension.create(CircuitMakerGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<IngotPresserGUIMenu>> INGOT_PRESSER_GUI = REGISTRY.register("ingot_presser_gui", () -> IMenuTypeExtension.create(IngotPresserGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<GeneratorGUIMenu>> GENERATOR_GUI = REGISTRY.register("generator_gui", () -> IMenuTypeExtension.create(GeneratorGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<IronOrePromptMenu>> IRON_ORE_PROMPT = REGISTRY.register("iron_ore_prompt", () -> IMenuTypeExtension.create(IronOrePromptMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<BiomeSelectorMenu>> BIOME_SELECTOR = REGISTRY.register("biome_selector", () -> IMenuTypeExtension.create(BiomeSelectorMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ImbunementGUIMenu>> IMBUNEMENT_GUI = REGISTRY.register("imbunement_gui", () -> IMenuTypeExtension.create(ImbunementGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<IncineratorGUIMenu>> INCINERATOR_GUI = REGISTRY.register("incinerator_gui", () -> IMenuTypeExtension.create(IncineratorGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<CorruptorGUIMenu>> CORRUPTOR_GUI = REGISTRY.register("corruptor_gui", () -> IMenuTypeExtension.create(CorruptorGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ElectricSmelterGUIMenu>> ELECTRIC_SMELTER_GUI = REGISTRY.register("electric_smelter_gui", () -> IMenuTypeExtension.create(ElectricSmelterGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<NuclearReactorGUIMenu>> NUCLEAR_REACTOR_GUI = REGISTRY.register("nuclear_reactor_gui", () -> IMenuTypeExtension.create(NuclearReactorGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<BackpackGUIMenu>> BACKPACK_GUI = REGISTRY.register("backpack_gui", () -> IMenuTypeExtension.create(BackpackGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<AlloySmelterGUIMenu>> ALLOY_SMELTER_GUI = REGISTRY.register("alloy_smelter_gui", () -> IMenuTypeExtension.create(AlloySmelterGUIMenu::new));
}
