
package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import com.lordkittycat.alternate_dimension.init.AlternateDimensionModFluids;

public class MoltenGoldItem extends BucketItem {
	public MoltenGoldItem() {
		super(AlternateDimensionModFluids.MOLTEN_GOLD.get(), new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON));
	}
}
