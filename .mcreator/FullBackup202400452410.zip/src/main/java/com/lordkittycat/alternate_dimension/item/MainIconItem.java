
package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class MainIconItem extends Item {
	public MainIconItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
	}
}
