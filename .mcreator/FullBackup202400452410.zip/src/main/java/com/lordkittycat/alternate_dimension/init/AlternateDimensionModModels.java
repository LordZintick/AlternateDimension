
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.lordkittycat.alternate_dimension.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import com.lordkittycat.alternate_dimension.client.model.Modelwolf;
import com.lordkittycat.alternate_dimension.client.model.Modelturtle;
import com.lordkittycat.alternate_dimension.client.model.Modelspirit;
import com.lordkittycat.alternate_dimension.client.model.Modelpolar_bear;
import com.lordkittycat.alternate_dimension.client.model.Modelplayer_model;
import com.lordkittycat.alternate_dimension.client.model.Modelgingerbread_warrior;
import com.lordkittycat.alternate_dimension.client.model.Modelcat;
import com.lordkittycat.alternate_dimension.client.model.Modelcandy_jetpack;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class AlternateDimensionModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelcat.LAYER_LOCATION, Modelcat::createBodyLayer);
		event.registerLayerDefinition(Modelgingerbread_warrior.LAYER_LOCATION, Modelgingerbread_warrior::createBodyLayer);
		event.registerLayerDefinition(Modelwolf.LAYER_LOCATION, Modelwolf::createBodyLayer);
		event.registerLayerDefinition(Modelcandy_jetpack.LAYER_LOCATION, Modelcandy_jetpack::createBodyLayer);
		event.registerLayerDefinition(Modelspirit.LAYER_LOCATION, Modelspirit::createBodyLayer);
		event.registerLayerDefinition(Modelplayer_model.LAYER_LOCATION, Modelplayer_model::createBodyLayer);
		event.registerLayerDefinition(Modelturtle.LAYER_LOCATION, Modelturtle::createBodyLayer);
		event.registerLayerDefinition(Modelpolar_bear.LAYER_LOCATION, Modelpolar_bear::createBodyLayer);
	}
}
