
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.lordkittycat.alternate_dimension.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import com.lordkittycat.alternate_dimension.block.entity.SolarPanelBlockEntity;
import com.lordkittycat.alternate_dimension.block.entity.PortalBlockBlockEntity;
import com.lordkittycat.alternate_dimension.block.entity.NuclearReactorBlockEntity;
import com.lordkittycat.alternate_dimension.block.entity.IngotPresserBlockEntity;
import com.lordkittycat.alternate_dimension.block.entity.ImbunementTableBlockEntity;
import com.lordkittycat.alternate_dimension.block.entity.GeneratorBlockEntity;
import com.lordkittycat.alternate_dimension.block.entity.ElectricSmelterBlockEntity;
import com.lordkittycat.alternate_dimension.block.entity.CorruptorBlockEntity;
import com.lordkittycat.alternate_dimension.block.entity.CircuitMakerBlockEntity;
import com.lordkittycat.alternate_dimension.block.entity.BasicEnergyCableBlockEntity;
import com.lordkittycat.alternate_dimension.block.entity.AlloySmelterBlockEntity;
import com.lordkittycat.alternate_dimension.AlternateDimensionMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class AlternateDimensionModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, AlternateDimensionMod.MODID);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> CIRCUIT_MAKER = register("circuit_maker", AlternateDimensionModBlocks.CIRCUIT_MAKER, CircuitMakerBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> INGOT_PRESSER = register("ingot_presser", AlternateDimensionModBlocks.INGOT_PRESSER, IngotPresserBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> GENERATOR = register("generator", AlternateDimensionModBlocks.GENERATOR, GeneratorBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> SOLAR_PANEL = register("solar_panel", AlternateDimensionModBlocks.SOLAR_PANEL, SolarPanelBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> BASIC_ENERGY_CABLE = register("basic_energy_cable", AlternateDimensionModBlocks.BASIC_ENERGY_CABLE, BasicEnergyCableBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> IMBUNEMENT_TABLE = register("imbunement_table", AlternateDimensionModBlocks.IMBUNEMENT_TABLE, ImbunementTableBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> CORRUPTOR = register("corruptor", AlternateDimensionModBlocks.CORRUPTOR, CorruptorBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> ELECTRIC_SMELTER = register("electric_smelter", AlternateDimensionModBlocks.ELECTRIC_SMELTER, ElectricSmelterBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> NUCLEAR_REACTOR = register("nuclear_reactor", AlternateDimensionModBlocks.NUCLEAR_REACTOR, NuclearReactorBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> ALLOY_SMELTER = register("alloy_smelter", AlternateDimensionModBlocks.ALLOY_SMELTER, AlloySmelterBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> PORTAL_BLOCK = register("portal_block", AlternateDimensionModBlocks.PORTAL_BLOCK, PortalBlockBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> register(String registryname, DeferredHolder<Block, Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, CIRCUIT_MAKER.get(), (blockEntity, side) -> ((CircuitMakerBlockEntity) blockEntity).getItemHandler());
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, CIRCUIT_MAKER.get(), (blockEntity, side) -> ((CircuitMakerBlockEntity) blockEntity).getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, INGOT_PRESSER.get(), (blockEntity, side) -> ((IngotPresserBlockEntity) blockEntity).getItemHandler());
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, INGOT_PRESSER.get(), (blockEntity, side) -> ((IngotPresserBlockEntity) blockEntity).getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, GENERATOR.get(), (blockEntity, side) -> ((GeneratorBlockEntity) blockEntity).getItemHandler());
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, GENERATOR.get(), (blockEntity, side) -> ((GeneratorBlockEntity) blockEntity).getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, SOLAR_PANEL.get(), (blockEntity, side) -> ((SolarPanelBlockEntity) blockEntity).getItemHandler());
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, SOLAR_PANEL.get(), (blockEntity, side) -> ((SolarPanelBlockEntity) blockEntity).getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, BASIC_ENERGY_CABLE.get(), (blockEntity, side) -> ((BasicEnergyCableBlockEntity) blockEntity).getItemHandler());
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, BASIC_ENERGY_CABLE.get(), (blockEntity, side) -> ((BasicEnergyCableBlockEntity) blockEntity).getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, IMBUNEMENT_TABLE.get(), (blockEntity, side) -> ((ImbunementTableBlockEntity) blockEntity).getItemHandler());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, CORRUPTOR.get(), (blockEntity, side) -> ((CorruptorBlockEntity) blockEntity).getItemHandler());
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, CORRUPTOR.get(), (blockEntity, side) -> ((CorruptorBlockEntity) blockEntity).getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ELECTRIC_SMELTER.get(), (blockEntity, side) -> ((ElectricSmelterBlockEntity) blockEntity).getItemHandler());
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ELECTRIC_SMELTER.get(), (blockEntity, side) -> ((ElectricSmelterBlockEntity) blockEntity).getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, NUCLEAR_REACTOR.get(), (blockEntity, side) -> ((NuclearReactorBlockEntity) blockEntity).getItemHandler());
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, NUCLEAR_REACTOR.get(), (blockEntity, side) -> ((NuclearReactorBlockEntity) blockEntity).getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ALLOY_SMELTER.get(), (blockEntity, side) -> ((AlloySmelterBlockEntity) blockEntity).getItemHandler());
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ALLOY_SMELTER.get(), (blockEntity, side) -> ((AlloySmelterBlockEntity) blockEntity).getEnergyStorage());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, PORTAL_BLOCK.get(), (blockEntity, side) -> ((PortalBlockBlockEntity) blockEntity).getItemHandler());
	}
}
