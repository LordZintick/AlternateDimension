
package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class PlusItem extends Item {
	public PlusItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
