
package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LembasBreadItem extends Item {
	public LembasBreadItem() {
		super(new Item.Properties().durability(16).rarity(Rarity.UNCOMMON));
	}
}
