
package com.lordkittycat.alternate_dimension.jei_recipes;

import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.GuiGraphics;

import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.constants.VanillaTypes;

import com.lordkittycat.alternate_dimension.init.AlternateDimensionModJeiPlugin;
import com.lordkittycat.alternate_dimension.init.AlternateDimensionModBlocks;

public class IngotPresserRecipeTypeRecipeCategory implements IRecipeCategory<IngotPresserRecipeTypeRecipe> {
	public final static ResourceLocation UID = ResourceLocation.parse("alternate_dimension:ingot_presser_recipe_type");
	public final static ResourceLocation TEXTURE = ResourceLocation.parse("alternate_dimension:textures/screens/ingot_presser_recipe_gui.png");
	private final IDrawable background;
	private final IDrawable icon;

	public IngotPresserRecipeTypeRecipeCategory(IGuiHelper helper) {
		this.background = helper.createDrawable(TEXTURE, 0, 0, 176, 185);
		this.icon = helper.createDrawableIngredient(VanillaTypes.ITEM_STACK, new ItemStack(AlternateDimensionModBlocks.INGOT_PRESSER.get().asItem()));
	}

	@Override
	public mezz.jei.api.recipe.RecipeType<IngotPresserRecipeTypeRecipe> getRecipeType() {
		return AlternateDimensionModJeiPlugin.IngotPresserRecipeType_Type;
	}

	@Override
	public Component getTitle() {
		return Component.literal("Ingot Pressing");
	}

	@Override
	public IDrawable getIcon() {
		return this.icon;
	}

	@Override
	public int getWidth() {
		return this.background.getWidth();
	}

	@Override
	public int getHeight() {
		return this.background.getHeight();
	}

	@Override
	public void draw(IngotPresserRecipeTypeRecipe recipe, IRecipeSlotsView recipeSlotsView, GuiGraphics guiGraphics, double mouseX, double mouseY) {
		this.background.draw(guiGraphics);
	}

	@Override
	public void setRecipe(IRecipeLayoutBuilder builder, IngotPresserRecipeTypeRecipe recipe, IFocusGroup focuses) {
		builder.addSlot(RecipeIngredientRole.INPUT, 58, 47).addIngredients(recipe.getIngredients().get(0));
		builder.addSlot(RecipeIngredientRole.OUTPUT, 82, 47).addItemStack(recipe.getResultItem(null));
	}
}
