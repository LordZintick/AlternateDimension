
package com.lordkittycat.alternate_dimension.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.core.BlockPos;

import com.mojang.serialization.MapCodec;

public class MagicDustBlockBlock extends FallingBlock {
	public static final MapCodec<MagicDustBlockBlock> CODEC = simpleCodec(properties -> new MagicDustBlockBlock());

	public MapCodec<MagicDustBlockBlock> codec() {
		return CODEC;
	}

	public MagicDustBlockBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.SAND).strength(1f, 10f));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}
}
