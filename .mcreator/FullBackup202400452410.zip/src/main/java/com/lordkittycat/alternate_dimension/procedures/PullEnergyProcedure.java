package com.lordkittycat.alternate_dimension.procedures;

import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class PullEnergyProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double transferamnt = 0;
		for (Direction directioniterator : Direction.values()) {
			if (new Object() {
				public boolean canExtractEnergy(LevelAccessor level, BlockPos pos) {
					if (level instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, pos, (directioniterator.getOpposite()));
						if (_entityStorage != null)
							return _entityStorage.canExtract();
					}
					return false;
				}
			}.canExtractEnergy(world, BlockPos.containing(x + directioniterator.getStepX(), y + directioniterator.getStepY(), z + directioniterator.getStepZ())) && new Object() {
				public boolean canReceiveEnergy(LevelAccessor level, BlockPos pos) {
					if (level instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, pos, directioniterator);
						if (_entityStorage != null)
							return _entityStorage.canReceive();
					}
					return false;
				}
			}.canReceiveEnergy(world, BlockPos.containing(x, y, z)) && new Object() {
				public int getEnergyStored(LevelAccessor level, BlockPos pos) {
					if (level instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, pos, null);
						if (_entityStorage != null)
							return _entityStorage.getEnergyStored();
					}
					return 0;
				}
			}.getEnergyStored(world, BlockPos.containing(x, y, z)) < new Object() {
				public int getMaxEnergyStored(LevelAccessor level, BlockPos pos) {
					if (level instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, pos, null);
						if (_entityStorage != null)
							return _entityStorage.getMaxEnergyStored();
					}
					return 0;
				}
			}.getMaxEnergyStored(world, BlockPos.containing(x, y, z))) {
				transferamnt = new Object() {
					public int extractEnergySimulate(LevelAccessor level, BlockPos pos, int _amount) {
						if (level instanceof ILevelExtension _ext) {
							IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, pos, (directioniterator.getOpposite()));
							if (_entityStorage != null)
								return _entityStorage.extractEnergy(_amount, true);
						}
						return 0;
					}
				}.extractEnergySimulate(world, BlockPos.containing(x + directioniterator.getStepX(), y + directioniterator.getStepY(), z + directioniterator.getStepZ()), 10000);
				if (world instanceof ILevelExtension _ext) {
					IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x + directioniterator.getStepX(), y + directioniterator.getStepY(), z + directioniterator.getStepZ()),
							(directioniterator.getOpposite()));
					if (_entityStorage != null)
						_entityStorage.extractEnergy((int) transferamnt, false);
				}
				if (world instanceof ILevelExtension _ext) {
					IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x, y, z), directioniterator);
					if (_entityStorage != null)
						_entityStorage.receiveEnergy((int) transferamnt, false);
				}
			}
		}
	}
}
