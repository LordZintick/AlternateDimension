package com.lordkittycat.alternate_dimension.procedures;

import net.minecraft.world.item.ItemStack;

import com.lordkittycat.alternate_dimension.init.AlternateDimensionModItems;

public class CheckForRuneSlateProcedure {
	public static boolean execute(ItemStack itemstack) {
		return !(itemstack.getItem() == AlternateDimensionModItems.RUNE_SLATE.get());
	}
}
