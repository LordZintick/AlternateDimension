
package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class HempItem extends Item {
	public HempItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
