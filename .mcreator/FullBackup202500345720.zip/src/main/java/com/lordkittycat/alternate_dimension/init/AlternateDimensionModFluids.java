/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package com.lordkittycat.alternate_dimension.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import com.lordkittycat.alternate_dimension.fluid.MoltenIronFluid;
import com.lordkittycat.alternate_dimension.fluid.MoltenGoldFluid;
import com.lordkittycat.alternate_dimension.fluid.MoltenDiamondFluid;
import com.lordkittycat.alternate_dimension.AlternateDimensionMod;

public class AlternateDimensionModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, AlternateDimensionMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> MOLTEN_IRON = REGISTRY.register("molten_iron", () -> new MoltenIronFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_MOLTEN_IRON = REGISTRY.register("flowing_molten_iron", () -> new MoltenIronFluid.Flowing());
	public static final DeferredHolder<Fluid, FlowingFluid> MOLTEN_GOLD = REGISTRY.register("molten_gold", () -> new MoltenGoldFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_MOLTEN_GOLD = REGISTRY.register("flowing_molten_gold", () -> new MoltenGoldFluid.Flowing());
	public static final DeferredHolder<Fluid, FlowingFluid> MOLTEN_DIAMOND = REGISTRY.register("molten_diamond", () -> new MoltenDiamondFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_MOLTEN_DIAMOND = REGISTRY.register("flowing_molten_diamond", () -> new MoltenDiamondFluid.Flowing());

	@EventBusSubscriber(Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(MOLTEN_IRON.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_MOLTEN_IRON.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(MOLTEN_GOLD.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_MOLTEN_GOLD.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(MOLTEN_DIAMOND.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_MOLTEN_DIAMOND.get(), RenderType.translucent());
		}
	}
}