package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class DiamondPlateItem extends Item {
	public DiamondPlateItem() {
		super(new Item.Properties());
	}
}