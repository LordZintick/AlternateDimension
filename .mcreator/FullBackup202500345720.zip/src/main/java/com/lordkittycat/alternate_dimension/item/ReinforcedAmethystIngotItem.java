package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class ReinforcedAmethystIngotItem extends Item {
	public ReinforcedAmethystIngotItem() {
		super(new Item.Properties());
	}
}