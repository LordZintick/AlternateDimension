package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class OrichalcumPlateItem extends Item {
	public OrichalcumPlateItem() {
		super(new Item.Properties());
	}
}