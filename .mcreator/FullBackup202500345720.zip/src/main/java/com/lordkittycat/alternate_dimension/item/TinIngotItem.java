package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class TinIngotItem extends Item {
	public TinIngotItem() {
		super(new Item.Properties());
	}
}