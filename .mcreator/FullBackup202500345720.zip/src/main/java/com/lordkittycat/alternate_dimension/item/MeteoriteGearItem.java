package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class MeteoriteGearItem extends Item {
	public MeteoriteGearItem() {
		super(new Item.Properties());
	}
}