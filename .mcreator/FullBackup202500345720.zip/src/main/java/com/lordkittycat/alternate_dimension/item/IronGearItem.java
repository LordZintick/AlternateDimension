package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class IronGearItem extends Item {
	public IronGearItem() {
		super(new Item.Properties());
	}
}