/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.lordkittycat.alternate_dimension.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import com.lordkittycat.alternate_dimension.block.*;
import com.lordkittycat.alternate_dimension.AlternateDimensionMod;

public class AlternateDimensionModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(AlternateDimensionMod.MODID);
	public static final DeferredBlock<Block> TITANIUM_ORE;
	public static final DeferredBlock<Block> TITANIUM_BLOCK;
	public static final DeferredBlock<Block> DEEPSLATE_TITANIUM_ORE;
	public static final DeferredBlock<Block> SCORCHED_EARTH;
	public static final DeferredBlock<Block> DRIED_FRUIT;
	public static final DeferredBlock<Block> CIRCUIT_MAKER;
	public static final DeferredBlock<Block> INGOT_PRESSER;
	public static final DeferredBlock<Block> QUARTZ_ORE;
	public static final DeferredBlock<Block> GENERATOR;
	public static final DeferredBlock<Block> MOLTEN_IRON;
	public static final DeferredBlock<Block> MOLTEN_GOLD;
	public static final DeferredBlock<Block> SOLAR_PANEL;
	public static final DeferredBlock<Block> MOLTEN_DIAMOND;
	public static final DeferredBlock<Block> BASIC_ENERGY_CABLE;
	public static final DeferredBlock<Block> COMPRESSED_BARK;
	public static final DeferredBlock<Block> TIN_ORE;
	public static final DeferredBlock<Block> TIN_BLOCK;
	public static final DeferredBlock<Block> BEETLE_NEST;
	public static final DeferredBlock<Block> WILD_BUSH;
	public static final DeferredBlock<Block> SCORCHED_BUSH;
	public static final DeferredBlock<Block> SALT_BLOCK;
	public static final DeferredBlock<Block> FROSTING;
	public static final DeferredBlock<Block> CANDY_CANE_BLOCK;
	public static final DeferredBlock<Block> WAFFLE_BLOCK;
	public static final DeferredBlock<Block> COOKIE_BLOCK;
	public static final DeferredBlock<Block> CHEESE_BLOCK;
	public static final DeferredBlock<Block> LIGHTNING_BLOCK;
	public static final DeferredBlock<Block> BUSH_LEAVES;
	public static final DeferredBlock<Block> STONE_TILES;
	public static final DeferredBlock<Block> PARMESAN_CHEESE_BLOCK;
	public static final DeferredBlock<Block> HEMP_PLANT;
	public static final DeferredBlock<Block> SUGAR_BLOCK;
	public static final DeferredBlock<Block> SUGARIUM_ORE;
	public static final DeferredBlock<Block> SUGARIUM_BLOCK;
	public static final DeferredBlock<Block> SERVER_STATION;
	public static final DeferredBlock<Block> COOKING_CORE;
	public static final DeferredBlock<Block> SKY_STONE;
	public static final DeferredBlock<Block> METEORITE_BLOCK;
	public static final DeferredBlock<Block> SCORCHED_BRICKS;
	public static final DeferredBlock<Block> SCORCHED_BRICK_SLAB;
	public static final DeferredBlock<Block> SCORCHED_BRICK_STAIRS;
	public static final DeferredBlock<Block> RESTLESS_BEETLE_NEST;
	public static final DeferredBlock<Block> CLOUD_BLOCK;
	public static final DeferredBlock<Block> SULFUR_ORE;
	public static final DeferredBlock<Block> IMBUNEMENT_TABLE;
	public static final DeferredBlock<Block> HEART_OF_NATURE;
	public static final DeferredBlock<Block> CORRUPTOR;
	public static final DeferredBlock<Block> EVILSTONE_ORE;
	public static final DeferredBlock<Block> ELECTRIC_SMELTER;
	public static final DeferredBlock<Block> ORICHALCUM_ORE;
	public static final DeferredBlock<Block> CLOUD_BRICKS;
	public static final DeferredBlock<Block> CLOUD_BRICK_SLAB;
	public static final DeferredBlock<Block> CLOUD_BRICK_STAIRS;
	public static final DeferredBlock<Block> URANIUM_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_URANIUM_ORE;
	public static final DeferredBlock<Block> COOLANT_RODS;
	public static final DeferredBlock<Block> NUCLEAR_REACTOR;
	public static final DeferredBlock<Block> CLOUD_PILLAR;
	public static final DeferredBlock<Block> AERO_CORE;
	public static final DeferredBlock<Block> PINE_LEAVES;
	public static final DeferredBlock<Block> HOME_BLOCK;
	public static final DeferredBlock<Block> ALLOY_SMELTER;
	public static final DeferredBlock<Block> REFINED_METEORITE_BLOCK;
	public static final DeferredBlock<Block> EVILSTONE_BLOCK;
	public static final DeferredBlock<Block> MAGIC_DUST_BLOCK;
	public static final DeferredBlock<Block> ORICHALCUM_BLOCK;
	public static final DeferredBlock<Block> URANIUM_BLOCK;
	public static final DeferredBlock<Block> ICE_CREAM_BLOCK;
	public static final DeferredBlock<Block> WHIPPED_CREAM_BLOCK;
	public static final DeferredBlock<Block> APPLE_LEAVES;
	public static final DeferredBlock<Block> STRAWBERRY_BUSH;
	public static final DeferredBlock<Block> RASPBERRY_BUSH;
	public static final DeferredBlock<Block> BLUEBERRY_BUSH;
	public static final DeferredBlock<Block> PORTAL_BLOCK;
	static {
		TITANIUM_ORE = REGISTRY.register("titanium_ore", TitaniumOreBlock::new);
		TITANIUM_BLOCK = REGISTRY.register("titanium_block", TitaniumBlockBlock::new);
		DEEPSLATE_TITANIUM_ORE = REGISTRY.register("deepslate_titanium_ore", DeepslateTitaniumOreBlock::new);
		SCORCHED_EARTH = REGISTRY.register("scorched_earth", ScorchedEarthBlock::new);
		DRIED_FRUIT = REGISTRY.register("dried_fruit", DriedFruitBlock::new);
		CIRCUIT_MAKER = REGISTRY.register("circuit_maker", CircuitMakerBlock::new);
		INGOT_PRESSER = REGISTRY.register("ingot_presser", IngotPresserBlock::new);
		QUARTZ_ORE = REGISTRY.register("quartz_ore", QuartzOreBlock::new);
		GENERATOR = REGISTRY.register("generator", GeneratorBlock::new);
		MOLTEN_IRON = REGISTRY.register("molten_iron", MoltenIronBlock::new);
		MOLTEN_GOLD = REGISTRY.register("molten_gold", MoltenGoldBlock::new);
		SOLAR_PANEL = REGISTRY.register("solar_panel", SolarPanelBlock::new);
		MOLTEN_DIAMOND = REGISTRY.register("molten_diamond", MoltenDiamondBlock::new);
		BASIC_ENERGY_CABLE = REGISTRY.register("basic_energy_cable", BasicEnergyCableBlock::new);
		COMPRESSED_BARK = REGISTRY.register("compressed_bark", CompressedBarkBlock::new);
		TIN_ORE = REGISTRY.register("tin_ore", TinOreBlock::new);
		TIN_BLOCK = REGISTRY.register("tin_block", TinBlockBlock::new);
		BEETLE_NEST = REGISTRY.register("beetle_nest", BeetleNestBlock::new);
		WILD_BUSH = REGISTRY.register("wild_bush", WildBushBlock::new);
		SCORCHED_BUSH = REGISTRY.register("scorched_bush", ScorchedBushBlock::new);
		SALT_BLOCK = REGISTRY.register("salt_block", SaltBlockBlock::new);
		FROSTING = REGISTRY.register("frosting", FrostingBlock::new);
		CANDY_CANE_BLOCK = REGISTRY.register("candy_cane_block", CandyCaneBlockBlock::new);
		WAFFLE_BLOCK = REGISTRY.register("waffle_block", WaffleBlockBlock::new);
		COOKIE_BLOCK = REGISTRY.register("cookie_block", CookieBlockBlock::new);
		CHEESE_BLOCK = REGISTRY.register("cheese_block", CheeseBlockBlock::new);
		LIGHTNING_BLOCK = REGISTRY.register("lightning_block", LightningBlockBlock::new);
		BUSH_LEAVES = REGISTRY.register("bush_leaves", BushLeavesBlock::new);
		STONE_TILES = REGISTRY.register("stone_tiles", StoneTilesBlock::new);
		PARMESAN_CHEESE_BLOCK = REGISTRY.register("parmesan_cheese_block", ParmesanCheeseBlockBlock::new);
		HEMP_PLANT = REGISTRY.register("hemp_plant", HempPlantBlock::new);
		SUGAR_BLOCK = REGISTRY.register("sugar_block", SugarBlockBlock::new);
		SUGARIUM_ORE = REGISTRY.register("sugarium_ore", SugariumOreBlock::new);
		SUGARIUM_BLOCK = REGISTRY.register("sugarium_block", SugariumBlockBlock::new);
		SERVER_STATION = REGISTRY.register("server_station", ServerStationBlock::new);
		COOKING_CORE = REGISTRY.register("cooking_core", CookingCoreBlock::new);
		SKY_STONE = REGISTRY.register("sky_stone", SkyStoneBlock::new);
		METEORITE_BLOCK = REGISTRY.register("meteorite_block", MeteoriteBlockBlock::new);
		SCORCHED_BRICKS = REGISTRY.register("scorched_bricks", ScorchedBricksBlock::new);
		SCORCHED_BRICK_SLAB = REGISTRY.register("scorched_brick_slab", ScorchedBrickSlabBlock::new);
		SCORCHED_BRICK_STAIRS = REGISTRY.register("scorched_brick_stairs", ScorchedBrickStairsBlock::new);
		RESTLESS_BEETLE_NEST = REGISTRY.register("restless_beetle_nest", RestlessBeetleNestBlock::new);
		CLOUD_BLOCK = REGISTRY.register("cloud_block", CloudBlockBlock::new);
		SULFUR_ORE = REGISTRY.register("sulfur_ore", SulfurOreBlock::new);
		IMBUNEMENT_TABLE = REGISTRY.register("imbunement_table", ImbunementTableBlock::new);
		HEART_OF_NATURE = REGISTRY.register("heart_of_nature", HeartOfNatureBlock::new);
		CORRUPTOR = REGISTRY.register("corruptor", CorruptorBlock::new);
		EVILSTONE_ORE = REGISTRY.register("evilstone_ore", EvilstoneOreBlock::new);
		ELECTRIC_SMELTER = REGISTRY.register("electric_smelter", ElectricSmelterBlock::new);
		ORICHALCUM_ORE = REGISTRY.register("orichalcum_ore", OrichalcumOreBlock::new);
		CLOUD_BRICKS = REGISTRY.register("cloud_bricks", CloudBricksBlock::new);
		CLOUD_BRICK_SLAB = REGISTRY.register("cloud_brick_slab", CloudBrickSlabBlock::new);
		CLOUD_BRICK_STAIRS = REGISTRY.register("cloud_brick_stairs", CloudBrickStairsBlock::new);
		URANIUM_ORE = REGISTRY.register("uranium_ore", UraniumOreBlock::new);
		DEEPSLATE_URANIUM_ORE = REGISTRY.register("deepslate_uranium_ore", DeepslateUraniumOreBlock::new);
		COOLANT_RODS = REGISTRY.register("coolant_rods", CoolantRodsBlock::new);
		NUCLEAR_REACTOR = REGISTRY.register("nuclear_reactor", NuclearReactorBlock::new);
		CLOUD_PILLAR = REGISTRY.register("cloud_pillar", CloudPillarBlock::new);
		AERO_CORE = REGISTRY.register("aero_core", AeroCoreBlock::new);
		PINE_LEAVES = REGISTRY.register("pine_leaves", PineLeavesBlock::new);
		HOME_BLOCK = REGISTRY.register("home_block", HomeBlockBlock::new);
		ALLOY_SMELTER = REGISTRY.register("alloy_smelter", AlloySmelterBlock::new);
		REFINED_METEORITE_BLOCK = REGISTRY.register("refined_meteorite_block", RefinedMeteoriteBlockBlock::new);
		EVILSTONE_BLOCK = REGISTRY.register("evilstone_block", EvilstoneBlockBlock::new);
		MAGIC_DUST_BLOCK = REGISTRY.register("magic_dust_block", MagicDustBlockBlock::new);
		ORICHALCUM_BLOCK = REGISTRY.register("orichalcum_block", OrichalcumBlockBlock::new);
		URANIUM_BLOCK = REGISTRY.register("uranium_block", UraniumBlockBlock::new);
		ICE_CREAM_BLOCK = REGISTRY.register("ice_cream_block", IceCreamBlockBlock::new);
		WHIPPED_CREAM_BLOCK = REGISTRY.register("whipped_cream_block", WhippedCreamBlockBlock::new);
		APPLE_LEAVES = REGISTRY.register("apple_leaves", AppleLeavesBlock::new);
		STRAWBERRY_BUSH = REGISTRY.register("strawberry_bush", StrawberryBushBlock::new);
		RASPBERRY_BUSH = REGISTRY.register("raspberry_bush", RaspberryBushBlock::new);
		BLUEBERRY_BUSH = REGISTRY.register("blueberry_bush", BlueberryBushBlock::new);
		PORTAL_BLOCK = REGISTRY.register("portal_block", PortalBlockBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@EventBusSubscriber(Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			WildBushBlock.blockColorLoad(event);
			BushLeavesBlock.blockColorLoad(event);
			PineLeavesBlock.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
			WildBushBlock.itemColorLoad(event);
			BushLeavesBlock.itemColorLoad(event);
			PineLeavesBlock.itemColorLoad(event);
		}
	}
}