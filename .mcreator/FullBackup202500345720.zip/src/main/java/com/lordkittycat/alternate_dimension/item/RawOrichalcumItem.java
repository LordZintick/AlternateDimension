package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class RawOrichalcumItem extends Item {
	public RawOrichalcumItem() {
		super(new Item.Properties());
	}
}