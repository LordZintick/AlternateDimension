/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package com.lordkittycat.alternate_dimension.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import com.lordkittycat.alternate_dimension.fluid.types.MoltenIronFluidType;
import com.lordkittycat.alternate_dimension.fluid.types.MoltenGoldFluidType;
import com.lordkittycat.alternate_dimension.fluid.types.MoltenDiamondFluidType;
import com.lordkittycat.alternate_dimension.AlternateDimensionMod;

public class AlternateDimensionModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, AlternateDimensionMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> MOLTEN_IRON_TYPE = REGISTRY.register("molten_iron", () -> new MoltenIronFluidType());
	public static final DeferredHolder<FluidType, FluidType> MOLTEN_GOLD_TYPE = REGISTRY.register("molten_gold", () -> new MoltenGoldFluidType());
	public static final DeferredHolder<FluidType, FluidType> MOLTEN_DIAMOND_TYPE = REGISTRY.register("molten_diamond", () -> new MoltenDiamondFluidType());
}