package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class OrichalcumIngotItem extends Item {
	public OrichalcumIngotItem() {
		super(new Item.Properties().fireResistant());
	}
}