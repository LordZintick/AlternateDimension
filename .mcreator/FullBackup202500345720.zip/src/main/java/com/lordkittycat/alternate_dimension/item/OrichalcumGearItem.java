package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class OrichalcumGearItem extends Item {
	public OrichalcumGearItem() {
		super(new Item.Properties());
	}
}