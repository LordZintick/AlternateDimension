package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class TinGearItem extends Item {
	public TinGearItem() {
		super(new Item.Properties());
	}
}