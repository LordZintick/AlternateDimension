package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class GoldPlateItem extends Item {
	public GoldPlateItem() {
		super(new Item.Properties());
	}
}