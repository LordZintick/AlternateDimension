package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class TinPlateItem extends Item {
	public TinPlateItem() {
		super(new Item.Properties());
	}
}