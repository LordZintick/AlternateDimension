package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class RawTinItem extends Item {
	public RawTinItem() {
		super(new Item.Properties());
	}
}