package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import com.lordkittycat.alternate_dimension.init.AlternateDimensionModFluids;

public class MoltenIronItem extends BucketItem {
	public MoltenIronItem() {
		super(AlternateDimensionModFluids.MOLTEN_IRON.get(), new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}