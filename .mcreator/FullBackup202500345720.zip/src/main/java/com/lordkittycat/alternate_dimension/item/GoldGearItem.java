package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class GoldGearItem extends Item {
	public GoldGearItem() {
		super(new Item.Properties());
	}
}