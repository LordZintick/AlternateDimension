package com.lordkittycat.alternate_dimension.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

import com.lordkittycat.alternate_dimension.network.AlternateDimensionModVariables;
import com.lordkittycat.alternate_dimension.init.AlternateDimensionModItems;
import com.lordkittycat.alternate_dimension.init.AlternateDimensionModEntities;

@EventBusSubscriber
public class PlayerTickProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).jetpackHover && entity.getDeltaMovement().y() < 0
				&& (hasEntityInInventory(entity, new ItemStack(AlternateDimensionModItems.CANDY_CANE.get())) || entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).burnTime > 0)
				&& entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).jetpackEngine
				&& (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY).getItem() == AlternateDimensionModItems.CANDY_ARMOR_CHESTPLATE.get()) {
			if (entity instanceof LivingEntity _livingEntity4 && _livingEntity4.getAttributes().hasAttribute(Attributes.FLYING_SPEED))
				_livingEntity4.getAttribute(Attributes.FLYING_SPEED).setBaseValue(0.7);
			entity.fallDistance = 0;
			entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x()), 0, (entity.getDeltaMovement().z())));
			if (hasEntityInInventory(entity, new ItemStack(AlternateDimensionModItems.CANDY_CANE.get())) && entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).burnTime <= 0) {
				if (entity instanceof Player _player) {
					ItemStack _stktoremove = new ItemStack(AlternateDimensionModItems.CANDY_CANE.get());
					_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
				}
				{
					AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
					_vars.burnTime = 20;
					_vars.markSyncDirty();
				}
			} else {
				{
					AlternateDimensionModVariables.PlayerVariables _vars = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES);
					_vars.burnTime = entity.getData(AlternateDimensionModVariables.PLAYER_VARIABLES).burnTime - 1;
					_vars.markSyncDirty();
				}
			}
		} else {
			if (entity instanceof LivingEntity _livingEntity11 && _livingEntity11.getAttributes().hasAttribute(Attributes.FLYING_SPEED))
				_livingEntity11.getAttribute(Attributes.FLYING_SPEED).setBaseValue(0.1);
		}
		if (AlternateDimensionModVariables.WorldVariables.get(world).meteorCooldown > 0) {
			AlternateDimensionModVariables.WorldVariables.get(world).meteorCooldown = AlternateDimensionModVariables.WorldVariables.get(world).meteorCooldown - 1;
			AlternateDimensionModVariables.WorldVariables.get(world).markSyncDirty();
		} else {
			if (Mth.nextDouble(RandomSource.create(), 0, world.getBiome(BlockPos.containing(x, y, z)).is(ResourceLocation.parse("alternate_dimension:wasteland")) ? 500 : 1000) == 10 && world.canSeeSkyFromBelowWater(BlockPos.containing(x, y, z))) {
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("item.goat_horn.sound.3")), SoundSource.AMBIENT, 1, 1);
					} else {
						_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("item.goat_horn.sound.3")), SoundSource.AMBIENT, 1, 1, false);
					}
				}
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = AlternateDimensionModEntities.METEOROID.get().spawn(_level, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -128, 128), y + 128, z + Mth.nextInt(RandomSource.create(), -128, 128)),
							MobSpawnType.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
					}
				}
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("A meteoroid is falling from the sky!"), true);
				AlternateDimensionModVariables.WorldVariables.get(world).meteorCooldown = 2400;
				AlternateDimensionModVariables.WorldVariables.get(world).markSyncDirty();
			}
		}
	}

	private static boolean hasEntityInInventory(Entity entity, ItemStack itemstack) {
		if (entity instanceof Player player)
			return player.getInventory().contains(stack -> !stack.isEmpty() && ItemStack.isSameItem(stack, itemstack));
		return false;
	}
}