package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class IronPlateItem extends Item {
	public IronPlateItem() {
		super(new Item.Properties());
	}
}