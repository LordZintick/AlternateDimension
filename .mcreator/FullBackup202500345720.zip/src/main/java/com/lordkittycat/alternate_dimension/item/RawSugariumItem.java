package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class RawSugariumItem extends Item {
	public RawSugariumItem() {
		super(new Item.Properties());
	}
}