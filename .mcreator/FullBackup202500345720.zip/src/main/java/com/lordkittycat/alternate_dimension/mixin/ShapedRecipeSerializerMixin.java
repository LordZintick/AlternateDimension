package com.lordkittycat.alternate_dimension.mixin;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.item.crafting.ShapedRecipe;
import org.apache.logging.log4j.LogManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ShapedRecipe.Serializer.class)
public abstract class ShapedRecipeSerializerMixin {
    @Inject(method = "toNetwork", at = @At("HEAD"))
    private static void debugRecipeEncoding(RegistryFriendlyByteBuf p_320738_, ShapedRecipe p_320586_, CallbackInfo ci) {
        // Log every recipe ID as it's being encoded.
        // The last one logged before the crash is your culprit.
        LogManager.getLogger().info("Encoding recipe with group: " + p_320586_.getGroup());
    }
}
