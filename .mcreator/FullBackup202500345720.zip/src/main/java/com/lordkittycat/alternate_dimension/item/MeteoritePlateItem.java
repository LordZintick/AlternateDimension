package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class MeteoritePlateItem extends Item {
	public MeteoritePlateItem() {
		super(new Item.Properties());
	}
}