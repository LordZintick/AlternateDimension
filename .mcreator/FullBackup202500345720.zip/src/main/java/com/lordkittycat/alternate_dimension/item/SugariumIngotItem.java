package com.lordkittycat.alternate_dimension.item;

import net.minecraft.world.item.Item;

public class SugariumIngotItem extends Item {
	public SugariumIngotItem() {
		super(new Item.Properties());
	}
}